#
# Copyright 2016 Pixar
#
# Licensed under the terms set forth in the LICENSE.txt file available at
# https://openusd.org/license.
#
function(_add_define definition)
    list(APPEND _PXR_CXX_DEFINITIONS "-D${definition}")
    set(_PXR_CXX_DEFINITIONS ${_PXR_CXX_DEFINITIONS} PARENT_SCOPE)
endfunction()

function(_disable_warning flag)
    # R package builds preserve all caller/compiler diagnostics.
endfunction()

// Modified for libopenusd by Tyler Morgan-Wall, 2026: R embedding; see tools/vendor/README.md.
#include "pxr/base/arch/rDiagnostics.h"
//
// Copyright 2016 Pixar
//
// Licensed under the terms set forth in the LICENSE.txt file available at
// https://openusd.org/license.
//
#include "pxr/pxr.h"
#include "pxr/base/arch/defines.h"
#include "pxr/base/arch/stackTrace.h"
#include "pxr/base/arch/attributes.h"
#include "pxr/base/arch/debugger.h"
#include "pxr/base/arch/defines.h"
#include "pxr/base/arch/demangle.h"
#include "pxr/base/arch/env.h"
#include "pxr/base/arch/error.h"
#include "pxr/base/arch/errno.h"
#include "pxr/base/arch/export.h"
#if defined(ARCH_OS_WINDOWS)
// Need to include Winsock2.h BEFORE windows.h - which is included in
// fileSystem.h
#include <Winsock2.h>
#endif
#include "pxr/base/arch/fileSystem.h"
#include "pxr/base/arch/inttypes.h"
#include "pxr/base/arch/symbols.h"
#include "pxr/base/arch/vsnprintf.h"
#if defined(ARCH_OS_WINDOWS)
#include <io.h>
#include <process.h>
#include <DbgHelp.h>
#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN 64
#endif
#else
#include <dlfcn.h>
#include <fcntl.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/param.h>
#include <sys/resource.h>
#include <sys/wait.h>
#endif
#include <algorithm>
#include <atomic>
#include <csignal>
#include <fstream>
#include <ostream>
#include <iterator>
#include <limits>
#include <cstdlib>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <thread>

/* Darwin/ppc did not do stack traces.  Darwin/i386 still 
   needs some work, this has been stubbed out for now.  */

#if defined(ARCH_OS_LINUX)
#include <ucontext.h>
#endif

#if defined(ARCH_OS_LINUX) && defined(ARCH_BITS_64)
#include <unwind.h>
#endif

#if defined(ARCH_OS_DARWIN)
#include <execinfo.h>
#endif

#if defined(ARCH_OS_WINDOWS)
#define getpid() _getpid()
#define write(fd_, data_, size_) _write(fd_, data_, size_)
#define strdup(str_) _strdup(str_)
#endif

#include <string>
#include <vector>
#include <map>
#include <sstream>
#include <time.h>

PXR_NAMESPACE_OPEN_SCOPE

using namespace std;

#define MAX_STACK_DEPTH 4096

#if !defined(ARCH_OS_WINDOWS)
// XXX Darwin
// total hack -- no idea if this will work if we die in malloc...
typedef int (*ForkFunc)(void);
ForkFunc Arch_nonLockingFork =
#if defined(ARCH_OS_LINUX)
    (ForkFunc)dlsym(RTLD_DEFAULT, "_Fork");
#elif defined(ARCH_OS_DARWIN) || defined(ARCH_OS_WASM_VM)
    NULL;
#else
#error Unknown architecture.
#endif
#endif

/*** Stack Logging Global Variables ***/

// Stores the application's launch time
static time_t _appLaunchTime;

// Hostname cached at load time, before any signal handler can fire.  Used
// during crash reporting; gethostname() is not on POSIX's async-signal-safe
// list and may allocate on some platforms, so we capture it once up front and
// read the buffer in the signal handler.
//
// The buffer is one byte larger than the size we hand to gethostname(). Static
// storage zero-initializes it.  This means:
// - On success, the string is NUL-terminated.
// - On ENAMETOOLONG (system hostname too long for our buffer), POSIX leaves it
//   unspecified whether the truncated name is NUL-terminated -- the trailing
//   reserved byte still terminates the string, and we keep whatever was
//   written rather than wiping the partial name.
// - On any other failure, the buffer remains all zeros (empty string).
static char _hostname[MAXHOSTNAMELEN + 1];
namespace {
const bool _hostnameInited = []() {
    // Pass sizeof - 1 so the final byte stays zero-initialized.
    gethostname(_hostname, sizeof(_hostname) - 1);
    return true;
}();
}

// This bool determines whether a stack trace should be
// logged upon catching a crash. Use ArchSetFatalStackLogging
// to set this value.
//
// All of the configuration globals below may be read from a signal handler
// concurrently with non-handler writes, so they are std::atomic.  Setters are
// expected to run during process init, well before signals fire, but the API
// doesn't forbid concurrent updates.
static std::atomic<bool> _shouldLogStackToDb {false};

// This string holds the path the script used to log sessions
// to a database.
static std::atomic<const char*> _logStackToDbCmd {nullptr};

// Arguments to _logStackToDbCmd for non-crash and crash reports, respectively.
static std::atomic<const char* const*> _sessionLogArgv {nullptr};
static std::atomic<const char* const*> _sessionCrashLogArgv {nullptr};

// This string stores the program name to be used when
// displaying error information.  Initialized in
// Arch_InitConfig() to ArchGetExecutablePath().
//
// Stored atomically.  Set via ArchSetProgramNameForErrors which publishes
// the new value before freeing the old one, so a signal-handler reader
// never sees a half-published or freed pointer.  In practice this setter
// runs once during process init.
static std::atomic<char*> _progNameForErrors {nullptr};

// Flag indicating whether the crash signal handler has been invoked.
// Use a type that's safe in the presence of asynchronous signals.
static volatile std::sig_atomic_t _isCrashing = 0;

namespace {
void aswrite(int fd, const char* msg);

// A tiny mutex built on std::atomic_flag in order to be async-signal-safe.
// Compatible with std::lock_guard.
class _AtomicFlagMutex
{
public:
    constexpr _AtomicFlagMutex() = default;
    _AtomicFlagMutex(const _AtomicFlagMutex&) = delete;
    _AtomicFlagMutex& operator=(const _AtomicFlagMutex&) = delete;

    void lock() {
        while (_flag.test_and_set(std::memory_order_acquire)) {
            std::this_thread::yield();
        }
    }
    bool try_lock() {
        return !_flag.test_and_set(std::memory_order_acquire);
    }
    void unlock() {
        _flag.clear(std::memory_order_release);
    }

private:
    std::atomic_flag _flag = ATOMIC_FLAG_INIT;
};

// Key-value map for program info. Stores additional
// program info to be used when displaying error information.
class Arch_ProgInfo
{
public:

    Arch_ProgInfo() : _progInfoForErrors(NULL) {}

    ~Arch_ProgInfo();

    void SetProgramInfoForErrors(const std::string& key,
                                 const std::string& value);

    std::string GetProgramInfoForErrors(const std::string& key) const;

    void PrintInfoForErrors() const;

private:
    typedef std::map<std::string, std::string> _MapType;
    _MapType _progInfoMap;
    mutable _AtomicFlagMutex _progInfoForErrorsMutex;

    // Printed version of _progInfo map, since we can't
    // traverse it during an error.
    char *_progInfoForErrors;
};

Arch_ProgInfo::~Arch_ProgInfo() 
{
    if (_progInfoForErrors)
        free(_progInfoForErrors);
}

void
Arch_ProgInfo::SetProgramInfoForErrors(
    const std::string& key, const std::string& value)
{
    std::lock_guard<_AtomicFlagMutex> lock(_progInfoForErrorsMutex);

    if (value.empty()) {
        _progInfoMap.erase(key);
    } else {
        _progInfoMap[key] = value;
    }

    std::ostringstream ss;

    // update the error info string
    for(_MapType::iterator iter = _progInfoMap.begin();
        iter != _progInfoMap.end(); ++iter) {

        ss << iter->first << ": " << iter->second << '\n';
    }

    if (_progInfoForErrors)
        free(_progInfoForErrors);

    _progInfoForErrors = strdup(ss.str().c_str());
}

std::string
Arch_ProgInfo::GetProgramInfoForErrors(const std::string& key) const
{
    std::lock_guard<_AtomicFlagMutex> lock(_progInfoForErrorsMutex);

    _MapType::const_iterator iter = _progInfoMap.find(key);
    std::string result;
    if (iter != _progInfoMap.end())
        result = iter->second;

    return result;
} 

void
Arch_ProgInfo::PrintInfoForErrors() const
{
    if (!_progInfoForErrorsMutex.try_lock()) {
        return;
    }
    std::lock_guard<_AtomicFlagMutex>
        lock(_progInfoForErrorsMutex, std::adopt_lock);
    if (_progInfoForErrors) {
        aswrite(2, _progInfoForErrors);
    }
}

} // anon-namespace

// Singletons for Arch_ProgInfo and Arch_LogInfo are stored as atomic pointers
// rather than function-local statics for two reasons: (1) the C++11 thread-
// safe-static guard mutex is not async-signal-safe, so a first-call from a
// signal handler can deadlock; (2) function-local statics run destructors at
// exit, and these singletons own STL containers / heap memory that we'd rather
// not touch during teardown.  The objects are intentionally leaked at process
// exit.
//
// Lazy creation goes through the heap (so it is NOT async-signal-safe).
// Crash-handler code must use the Try* accessors below, which are pure atomic
// loads and return nullptr if the singleton has not yet been constructed.
namespace {
template <class T>
T *
_GetOrCreate(std::atomic<T*>& slot)
{
    T *p = slot.load(std::memory_order_acquire);
    if (!p) {
        T *fresh = new T;
        T *expected = nullptr;
        if (slot.compare_exchange_strong(
                expected, fresh, std::memory_order_acq_rel)) {
            p = fresh;
        } else {
            // Lost the race; another thread published first.
            delete fresh;
            p = expected;
        }
    }
    return p;
}

std::atomic<Arch_ProgInfo*> _progInfoSingleton {nullptr};

} // anon-namespace

// Lazy create.  Not AS-safe; do not call from a signal handler.
static Arch_ProgInfo &
ArchStackTrace_GetProgInfo()
{
    return *_GetOrCreate(_progInfoSingleton);
}

namespace {

// Key-value map for extra log info.  Stores unowned pointers to text to be
// emitted in stack trace logs in case of fatal errors or crashes.
class Arch_LogInfo
{
public:
    void SetExtraLogInfoForErrors(const std::string &key,
                                  std::vector<std::string> const *lines);

    // Attempt to write the extra log info to outFile.  If maxLines > 0, writes
    // at most that many value lines (header lines do not count) plus a
    // truncation message.  NOT async-signal-safe.
    void EmitAnyExtraLogInfo(FILE *outFile, size_t maxLines = 0) const;

    // Attempt to write the extra log info to buf, up to one less than bufSize,
    // always null-terminates.  If maxLines > 0, writes at most that many value
    // lines (header lines do not count) and appends a truncation marker.
    // Return false in case of failure to acquire the lock or if not all the log
    // info was written.  Async-signal-safe for crash-handler paths.
    bool TryToFillLogInfoBuffer(char *buf, size_t bufSize,
                                size_t maxLines = 0) const;

private:
    // Walk the log map and invoke emit() for each chunk of text in emission
    // order: a leading "\n", the key name, ":\n", then each value line.
    // emit(const char *) must return false to signal that no more text can be
    // accepted (e.g., the destination buffer is full); the walk stops on the
    // first false return.  If maxLines > 0, after that many value lines a
    // truncation marker is emitted and the walk stops.  Returns true if the
    // entire map was emitted without truncation or refusal.
    //
    // Caller must hold _logInfoForErrorsMutex.
    template <class EmitFn>
    bool _ForEachLine(EmitFn emit, size_t maxLines) const;

    typedef std::map<std::string, std::vector<std::string> const *> _LogInfoMap;
    _LogInfoMap _logInfoForErrors;
    mutable _AtomicFlagMutex _logInfoForErrorsMutex;
};

template <class EmitFn>
bool
Arch_LogInfo::_ForEachLine(EmitFn emit, size_t maxLines) const
{
    size_t n = 0;
    for (auto const &kv : _logInfoForErrors) {
        if (!emit("\n") || !emit(kv.first.c_str()) || !emit(":\n")) {
            return false;
        }
        for (std::string const &line : *kv.second) {
            if (maxLines && n++ >= maxLines) {
                emit("... see full diagnostics in crash report.\n");
                return false;
            }
            if (!emit(line.c_str())) {
                return false;
            }
        }
    }
    return true;
}

void
Arch_LogInfo::SetExtraLogInfoForErrors(const std::string &key,
                                       std::vector<std::string> const *lines)
{
    std::lock_guard<_AtomicFlagMutex> lock(_logInfoForErrorsMutex);
    if (!lines || lines->empty()) {
        _logInfoForErrors.erase(key);
    } else {
        _logInfoForErrors[key] = lines;
    }
}

void
Arch_LogInfo::EmitAnyExtraLogInfo(FILE *outFile, size_t maxLines) const
{
    // Uses stdio (fputs) and is NOT async-signal-safe.  Callers on the
    // signal-handler path must use TryToFillLogInfoBuffer instead.
    if (!_logInfoForErrorsMutex.try_lock()) {
        return;
    }
    std::lock_guard<_AtomicFlagMutex>
        lock(_logInfoForErrorsMutex, std::adopt_lock);
    _ForEachLine([outFile](const char *s) {
        LibOpenUsdFputs(s, outFile);
        return true;
    }, maxLines);
}

bool
Arch_LogInfo::TryToFillLogInfoBuffer(char *buf, size_t bufSize,
                                     size_t maxLines) const
{
    if (!_logInfoForErrorsMutex.try_lock()) {
        buf[0] = '\0';
        return false;
    }
    std::lock_guard<_AtomicFlagMutex>
        lock(_logInfoForErrorsMutex, std::adopt_lock);

    char const * const bufEnd = buf + bufSize - 1;
    char *p = buf;
    return _ForEachLine([&p, bufEnd](const char *str) {
        while (*str && p != bufEnd) {
            *p++ = *str++;
        }
        *p = '\0';
        return p != bufEnd;
    }, maxLines);
}

std::atomic<Arch_LogInfo*> _logInfoSingleton{nullptr};
} // anon-namespace

// Lazy create.  Not AS-safe; do not call from a signal handler.
static Arch_LogInfo &
ArchStackTrace_GetLogInfo()
{
    return *_GetOrCreate(_logInfoSingleton);
}

static char const *
_GetExtraLogInfoReportDebugUnsafeImpl()
{
    static constexpr size_t bufSize = 1 * 1024 * 1024;
    static char buf[bufSize];
    ArchStackTrace_GetLogInfo().TryToFillLogInfoBuffer(buf, bufSize);
    return buf;
}

static void
_atexitCallback()
{
    ArchLogSessionInfo();
}

void
ArchEnableSessionLogging()
{
    static int unused = atexit(_atexitCallback);
    (void)unused;
}

static const char* const stackTracePrefix = "st";

static std::atomic<const char*>        _processStateCmd {nullptr};
static std::atomic<const char* const*> _nonFatalArgv    {nullptr};
static std::atomic<const char* const*> _fatalArgv       {nullptr};

static long _GetAppElapsedTime();

namespace {

// Return the length of s.
size_t asstrlen(const char* s)
{
    size_t result = 0;
    if (s) {
        while (*s++) {
            ++result;
        }
    }
    return result;
}

// Copy the string at src to dst, returning a pointer to the NUL terminator
// in dst (NOT a pointer to dst).
//
// ARCH_NOINLINE because old clang versions generated incorrect optimized
// code.
#if defined(ARCH_OS_DARWIN)
char* asstrcpy(char* dst, const char* src) ARCH_NOINLINE;
char* asstrcpy(char* dst, const char* src)
{
    while ((*dst++ = *src++)) {
        // Do nothing
    }
    return dst - 1;
}
#endif

// Compare the strings for equality.
bool asstreq(const char* dst, const char* src)
{
    if (!dst || !src) {
        return dst == src;
    }
    while (*dst || *src) {
        if (*dst++ != *src++) {
            return false;
        }
    }
    return true;
}

// Compare the strings for equality up to n characters.
bool asstrneq(const char* dst, const char* src, size_t n)
{
    if (!dst || !src) {
        return dst == src;
    }
    while ((*dst || *src) && n) {
        if (*dst++ != *src++) {
            return false;
        }
        --n;
    }
    return true;
}

// Returns the environment variable named name, or NULL if it doesn't exist.
const char* asgetenv(const char* name)
{
    if (name) {
        const size_t len = asstrlen(name);
        for (char** i = ArchEnviron(); *i; ++i) {
            const char* var = *i;
            if (asstrneq(var, name, len)) {
                if (var[len] == '=') {
                    return var + len + 1;
                }
            }
        }
    }
    return nullptr;
}

// Minimum safe size for a buffer to hold a long converted to decimal ASCII.
static constexpr int numericBufferSize =
    std::numeric_limits<long>::digits10
    + 1     // sign
    + 1     // overflow (digits10 doesn't necessarily count the high digit)
    + 1     // trailing NUL
    + 1;    // paranoia

// Return the number of digits in the decimal string representation of x.
size_t asNumDigits(long x)
{
    size_t result = 1;
    if (x < 0) {
        x = -x;
        ++result;
    }
    while (x >= 10) {
        ++result;
        x /= 10;
    }
    return result;
}

// Write the decimal string representation of x to s, which must have
// sufficient space available.
char* asitoa(char* s, long x)
{
    // Special-case zero up front so the digit loop below runs only for x != 0.
    // This avoids a GCC -Warray-bounds false positive when asitoa is inlined
    // into a caller with a known small buffer: the compiler can't always prove
    // asNumDigits(x) >= 1, and the *--s = '0' path triggers an incorrect
    // "subscript -1" warning.
    if (x == 0) {
        s[0] = '0';
        s[1] = '\0';
        return s + 1;
    }

    // Write the minus sign.
    if (x < 0) {
        x = -x;
        *s++ = '-';
    }

    // Skip to the end and write the terminating NUL.
    char* end = s += asNumDigits(x);
    *s = '\0';

    // Write each digit, starting with the 1's column, working backwards.
    static const char digit[] = "0123456789";
    while (x) {
        *--s = digit[x % 10];
        x /= 10;
    }
    return end;
}

// Write a string to a file descriptor.
void aswrite(int fd, const char* msg)
{
    int saved = errno;
    size_t len = asstrlen(msg);
    size_t written = 0;
    while (written < len) {
        if (fd == 1 || fd == 2) {
            LibOpenUsdFprintf(nullptr, "%.*s", static_cast<int>(len - written), msg + written);
            return;
        }
        ptrdiff_t n = write(fd, msg + written, len - written);
        if (n < 0) {
            // retry if the write is interrupted by a signal.
            if (errno == EINTR)
                continue;
            // Fail on any other error.
            break;
        }
        written += n;
    }
    errno = saved;
}

#if defined(ARCH_OS_DARWIN)
int _GetStackTraceName(char* buf, size_t len)
{
    // Take care to avoid non-async-safe functions.
    // NOTE: This doesn't protect against other threads changing the
    //       temporary directory or program name for errors.

    // Count the string length required.
    size_t required =
        asstrlen(ArchGetTmpDir()) +
        1 +     // "/"
        asstrlen(stackTracePrefix) +
        1 +     // "_"
        asstrlen(ArchGetProgramNameForErrors()) +
        1 +     // "."
        asNumDigits(getpid()) +
        1;      // "\0"

    // Fill in buf with the default name.
    char* end = buf;
    if (len < required) {
        // No space.  Not quite an accurate error code.
        errno = ENOMEM;
        return -1;
    }
    else {
        end = asstrcpy(end, ArchGetTmpDir());
        end = asstrcpy(end, "/");
        end = asstrcpy(end, stackTracePrefix);
        end = asstrcpy(end, "_");
        end = asstrcpy(end, ArchGetProgramNameForErrors());
        end = asstrcpy(end, ".");
        end = asitoa(end, getpid());
    }

    // Return a name that isn't currently in use.  Simultaneously create
    // the empty file.
    int suffix = 0;
#if defined(ARCH_OS_WINDOWS)
    int fd = _open(buf, O_CREAT | O_WRONLY | O_TRUNC | O_EXCL, 
                   _S_IREAD | _S_IWRITE);
#else
    int fd =  open(buf, O_CREAT | O_WRONLY | O_TRUNC | O_EXCL, 0640);
#endif

    while (fd == -1 && errno == EEXIST) {
        // File exists.  Try a new suffix if there's space.
        ++suffix;
        if (len < required + 1 + asNumDigits(suffix)) {
            // No space.  Not quite an accurate error code.
            errno = ENOMEM;
            return -1;
        }
        asstrcpy(end, ".");
        asitoa(end + 1, suffix);
#if defined(ARCH_OS_WINDOWS)
        fd = _open(buf, O_CREAT | O_WRONLY | O_TRUNC | O_EXCL, 
                   _S_IREAD | _S_IWRITE);
#else
        fd =  open(buf, O_CREAT | O_WRONLY | O_TRUNC | O_EXCL, 0640);
#endif
    }
    if (fd != -1) {
        ArchCloseFile(fd);
        fd = 0;
    }
    return fd;
}
#endif

// Build an argument list (async-safe).
static bool
_MakeArgv(
    const char* dstArgv[],
    size_t maxDstArgs,
    const char* cmd,
    const char* const srcArgv[],
    const char* const substitutions[][2],
    size_t numSubstitutions)
{
    if (!cmd || !srcArgv) {
        return false;
    }

    // Count the maximum number of arguments needed.
    size_t n = 1;
    for (const char *const* i = srcArgv; *i; ++n, ++i) {
        // Do nothing
    }

    // Make sure we don't have too many arguments.
    if (n >= maxDstArgs) {
        return false;
    }

    // Build the command line.
    size_t j = 0;
    for (size_t i = 0; i != n; ++i) {
        if (asstreq(srcArgv[i], "$cmd")) {
            dstArgv[j++] = cmd;
        }
        else {
            dstArgv[j] = srcArgv[i];
            for (size_t k = 0; k != numSubstitutions; ++k) {
                if (asstreq(srcArgv[i], substitutions[k][0])) {
                    dstArgv[j] = substitutions[k][1];
                    break;
                }
            }
            ++j;
        }
    }
    dstArgv[j] = nullptr;

    return true;
}

#if !defined(ARCH_OS_WINDOWS)
/* We use a 'non-locking' fork so that we won't get hung up if we've
 * had malloc corruption when we crash.  The crash recovery behavior
 * can be tested with ArchTestCrash(), which should crash with this
 * malloc corruption.
 */
#endif

#if !defined(ARCH_OS_WINDOWS)
/* This is the corresponding execv which works with nonLockingFork().
 * currently, it's only different from execv for linux.  The crash
 * recovery behavior can be tested with ArchTestCrash().
 */
#endif

/*
 * Return the base of a filename.
 */

static std::string
getBase(const char* path)
{
#if defined(ARCH_OS_WINDOWS)
    const std::string tmp = path;
    std::string::size_type i = tmp.find_last_of("/\\");
    if (i != std::string::npos) {
        std::string::size_type j = tmp.find(".exe");
        if (j != std::string::npos) {
            return tmp.substr(i + 1, j - i - 1);
        }
        return tmp.substr(i + 1);
    }
    return tmp;
#else
    const char* base = strrchr(path, '/');
    if (!base)
        return path;

    base++;
    return strlen(base) > 0 ? base : path;
#endif
}

} // anonymous namespace

/*
 * Run an external program to write post-mortem information to logfile for
 * process pid.  This waits until the program completes.
 *
 * This is an internal function used by ArchLogPostMortem().  It must call
 * only async-safe functions.
 */

#if defined(ARCH_OS_DARWIN)
static
int _LogStackTraceForPid(bool isFatal,
                         const char *logfile, 
                         const char *reason)
{
    // Get the command to run.
    const char* cmd = asgetenv("ARCH_POSTMORTEM");
    const char* const* cmdArgv =
        isFatal ? _fatalArgv.load(std::memory_order_acquire)
                : _nonFatalArgv.load(std::memory_order_acquire);
    if (!cmd) {
        cmd = _processStateCmd.load(std::memory_order_acquire);
    }
    if (!cmd || !cmdArgv) {
        // Silently do nothing.
        return 0;
    }

    // Construct the substitutions.
    char pidBuffer[numericBufferSize], timeBuffer[numericBufferSize];
    asitoa(pidBuffer, getpid());
    asitoa(timeBuffer, _GetAppElapsedTime());
    const char* const substitutions[4][2] = {
        { "$pid", pidBuffer }, 
        { "$log", logfile }, 
        { "$time", timeBuffer }, 
        { "$reason", reason }
    };

    // Build the argument list.
    static constexpr size_t maxArgs = 32;
    const char* argv[maxArgs];
    if (!_MakeArgv(argv, maxArgs, cmd, cmdArgv, substitutions, 4)) {
        static const char msg[] = "Too many arguments to postmortem command\n";
        aswrite(2, msg);
        return 0;
    }

    // Invoke the command.
    ArchCrashHandlerSystemv(argv[0], (char *const*)argv,
                            300 /* wait up to 300 seconds */ , NULL, NULL);
    return 1;
}
#endif

void
ArchSetProcessStateLogCommand(const char* command,
                              const char *const argv[],
                              const char *const fatalArgv[])
{
    _processStateCmd.store(command, std::memory_order_release);
    _nonFatalArgv.store(argv, std::memory_order_release);
    _fatalArgv.store(fatalArgv, std::memory_order_release);
}

/*
 * Arch_SetAppLaunchTime()
 * -------------------------------
 * Stores the current time as the application's launch time.
 * This function is internal.
 */
ARCH_HIDDEN
void
Arch_SetAppLaunchTime()
{
    _appLaunchTime = time(NULL);
}

/*
 * ArchGetAppLaunchTime()
 * -------------------------------
 * Returns the application's launch time, or NULL if a timestamp hasn't
 * been created with ArchSetAppLaunchTime().  
 */
time_t
ArchGetAppLaunchTime()
{
    // Defaults to NULL
    return _appLaunchTime;
}
 
/*
 * ArchSetFatalStackLogging()
 * -------------------------------
 * This enables the logging of the stack trace and other build
 * information upon intercepting a crash.
 *
 * This function can be called from python.
 */
void
ArchSetFatalStackLogging( bool flag )
{
    _shouldLogStackToDb.store(flag, std::memory_order_release);
}

/*
 * ArchGetFatalStackLogging()
 * ---------------------------
 * Returns the current value of the logging flag.
 *
 * This function can be called from python.
 */
bool
ArchGetFatalStackLogging()
{
    return _shouldLogStackToDb.load(std::memory_order_acquire);
}

void
ArchSetProgramInfoForErrors(const std::string& key,
                            const std::string& value)
{
    ArchStackTrace_GetProgInfo().SetProgramInfoForErrors(key, value);
}

std::string
ArchGetProgramInfoForErrors(const std::string& key) 
{
    return ArchStackTrace_GetProgInfo().GetProgramInfoForErrors(key);
} 

void
ArchSetExtraLogInfoForErrors(const std::string &key,
                             std::vector<std::string> const *lines)
{
    ArchStackTrace_GetLogInfo().SetExtraLogInfoForErrors(key, lines);
}

/*
 * ArchSetProgramNameForErrors
 * ---------------------------
 * Set's the program name that is to be used for diagnostic output.  
 */
void
ArchSetProgramNameForErrors( const char *progName )
{
    // Publish the new name before freeing the old one so a signal-handler
    // reader never sees a half-published or freed pointer.  A theoretical
    // use-after-free window remains if a signal handler captures the old
    // pointer and this setter then frees it before the signal handler
    // dereferences it, but in practice this setter is called once during
    // process init.
    char *newName = progName ? strdup(getBase(progName).c_str()) : nullptr;
    char *oldName =
        _progNameForErrors.exchange(newName, std::memory_order_acq_rel);
    if (oldName) {
        free(oldName);
    }
}

/*
 * ArchGetProgramNameForErrors
 * ----------------------------
 * Returns the currently set program name used for reporting error information.
 * Returns "pxr/arch" if a value hasn't been set.
 */
const char *
ArchGetProgramNameForErrors()
{
    const char *name = _progNameForErrors.load(std::memory_order_acquire);
    return name ? name : "pxr/arch";
}

#if defined(ARCH_OS_WINDOWS)
static long
_GetAppElapsedTime()
{
    FILETIME       starttime;
    FILETIME       exittime;
    FILETIME       kerneltime;
    FILETIME       usertime;
    ULARGE_INTEGER li;

    if (::GetProcessTimes(GetCurrentProcess(),
            &starttime, &exittime, &kerneltime, &usertime) == 0) {
        ARCH_WARNING("_GetAppElapsedTime failed");
        return 0L;
    }
    memcpy(&li, &usertime, sizeof(FILETIME));
    return static_cast<long>(li.QuadPart / 10000000ULL);
}
#else
static long
_GetAppElapsedTime()
{
    rusage ru;

    // We only record the amount of time spent in user instructions,
    // so as to discount idle time when logging up time.
    if (getrusage(RUSAGE_SELF, &ru) == 0) {
        return long(ru.ru_utime.tv_sec);
    }

    // Fallback to logging the entire session time, if we could
    // not get the user time from the resource usage.

    // Note: Total time measurement will be a little off because this
    // calculation happens after the stack trace is generated which can
    // take a long time.
    //
    return long(time(0) - _appLaunchTime);
}
#endif

static void
_InvokeSessionLogger(const char* progname, const char *stackTrace)
{
    // Get the command to run.
    const char* cmd = asgetenv("ARCH_LOGSESSION");
    const char* const* srcArgv =
        stackTrace ? _sessionCrashLogArgv.load(std::memory_order_acquire)
                   : _sessionLogArgv.load(std::memory_order_acquire);
    if (!cmd) {
        cmd = _logStackToDbCmd.load(std::memory_order_acquire);
    }
    if (!cmd || !srcArgv) {
        // Silently do nothing.
        return;
    }

    // Construct the substitutions.
    char pidBuffer[numericBufferSize], timeBuffer[numericBufferSize];
    asitoa(pidBuffer, getpid());
    asitoa(timeBuffer, _GetAppElapsedTime());
    const char* const substitutions[4][2] = {
        {"$pid", pidBuffer}, {"$time", timeBuffer},
        {"$prog", progname}, {"$stack", stackTrace}
    };

    // Build the argument list.
    static constexpr size_t maxArgs = 32;
    const char* argv[maxArgs];
    if (!_MakeArgv(argv, maxArgs, cmd, srcArgv, substitutions, 4)) {
        static const char msg[] = "Too many arguments to log session command\n";
        aswrite(2, msg);
        return;
    }

    // Invoke the command.
    ArchCrashHandlerSystemv(argv[0], (char *const*)argv, 
                            60 /* wait up to 60 seconds */, NULL, NULL);
}

/*
 * '_FinishLoggingFatalStackTrace' appends the sessionLog
 * to the stackTrace, and then calls an external program to add it
 * to the stack_trace database table.
 *
 * The crashingHard=false branch uses fopen/fputs/fgets/fclose and is therefore
 * not async-signal-safe.  Signal-handler callers MUST pass crashingHard=true so
 * that branch is skipped.
 */
static void
_FinishLoggingFatalStackTrace(const char *progname, const char *stackTrace,
                              const char *sessionLog, bool crashingHard)
{
    if (!crashingHard && sessionLog) {
        // If we were given a session log, cat it to the end of the stack.
        // Not async-signal-safe; only reached when crashingHard is false.
        if (FILE* stackFd = ArchOpenFile(stackTrace, "a")) {
            if (FILE* sessionLogFd = ArchOpenFile(sessionLog, "r")) {
                LibOpenUsdFputs("\n\n********** Session Log **********\n\n", stackFd);
                // Cat the session log
                char line[4096];
                while (fgets(line, 4096, sessionLogFd)) {
                    LibOpenUsdFputs(line, stackFd);
                }
                fclose(sessionLogFd);
            }
            fclose(stackFd);
        }
    }

    // Add trace to database if _shouldLogStackToDb is true
    if (_shouldLogStackToDb.load(std::memory_order_acquire))
    {
        _InvokeSessionLogger(progname, stackTrace);
    }

}

void
ArchLogSessionInfo(const char *crashStackTrace)
{
    if (_shouldLogStackToDb.load(std::memory_order_acquire))
    {
        _InvokeSessionLogger(ArchGetProgramNameForErrors(), crashStackTrace);
    }
}

void
ArchSetLogSession(
    const char* command,
    const char* const argv[],
    const char* const crashArgv[])
{
    _logStackToDbCmd.store(command, std::memory_order_release);
    _sessionLogArgv.store(argv, std::memory_order_release);
    _sessionCrashLogArgv.store(crashArgv, std::memory_order_release);
}

bool
ArchIsAppCrashing()
{
    return _isCrashing;
}

/*
 * Run an external program to make a report and tell the user where the report
 * file is.
 *
 * Use of char*'s is deliberate: only async-signal-safe calls allowed past this
 * point!  All output goes through aswrite (write(2)) -- never stdio because
 * stdio lazily allocates per-FILE buffers and takes per-FILE locks, both of
 * which deadlock if a signal interrupts malloc or another stdio call.
 */
static void
_ArchLogProcessStateHelper(bool isFatal,
                           const char* reason,
                           const char* message = nullptr,
                           const char* extraLogMsg = nullptr)
{
    LibOpenUsdFprintf(nullptr, "OpenUSD diagnostic: %s %s %s\n",
        reason ? reason : "", message ? message : "", extraLogMsg ? extraLogMsg : "");
}

void
ArchLogFatalProcessState(const char* reason,
                         const char* message /* = nullptr */,
                         const char* extraLogMsg /* = nullptr */)
{
    _ArchLogProcessStateHelper(true /* isFatal */, 
        reason, message, extraLogMsg);
}

void
ArchLogCurrentProcessState(const char* reason,
                           const char* message /* = nullptr */,
                           const char* extraLogMsg /* = nullptr */)
{
    _ArchLogProcessStateHelper(false /* isFatal */,
        reason, message, extraLogMsg);
}

/*
 * Write a stack trace to a file, without forking.
 */
void
ArchLogStackTrace(const std::string& reason, bool fatal, 
                  const string &sessionLog)
{
    ArchLogStackTrace(ArchGetProgramNameForErrors(), reason, fatal,
                      sessionLog);
}

/*
 * Write a stack trace to a file, without forking.
 *
 * Note: use of mktemp is not threadsafe.
 */
void
ArchLogStackTrace(const std::string& progname, const std::string& reason,
                  bool fatal, const string &sessionLog)
{
    string tmpFile;
    int fd = ArchMakeTmpFile(ArchStringPrintf("%s_%s",
                                              stackTracePrefix,
                                              ArchGetProgramNameForErrors()),
                             &tmpFile);

    LibOpenUsdFprintf(nullptr,
            "--------------------------------------------------------------\n"
            "A stack trace has been requested by %s because of %s\n",
            progname.c_str(), reason.c_str());

    // print out any registered program info
    {
        ArchStackTrace_GetProgInfo().PrintInfoForErrors();
    }

    if (fd != -1) {
        FILE* fout = ArchFdOpen(fd, "w");
        LibOpenUsdFprintf(nullptr, "The stack can be found in %s:%s\n"
                "--------------------------------------------------------------"
                "\n", _hostname, tmpFile.c_str());
        ArchPrintStackTrace(fout, progname, reason);
        /* If this is a fatal stack trace, attempt to add it to the db */
        if (fatal) {
            ArchStackTrace_GetLogInfo().EmitAnyExtraLogInfo(fout);
        }
        fclose(fout);
        if (fatal) {
            _FinishLoggingFatalStackTrace(progname.c_str(), tmpFile.c_str(),
                                          sessionLog.empty() ?  
                                          NULL : sessionLog.c_str(),
                                          false /* crashing hard? */);
        }
    }
    else {
        /* we couldn't open the tmp file, so write the stack trace to stderr */
        LibOpenUsdFprintf(nullptr,
                "--------------------------------------------------------------"
                "\n");
        ArchPrintStackTrace(nullptr, progname, reason);
        ArchStackTrace_GetLogInfo().EmitAnyExtraLogInfo(nullptr);
    }
    LibOpenUsdFprintf(nullptr,
            "--------------------------------------------------------------\n");
}

#if defined(ARCH_OS_DARWIN)

/*
 * This function will use _LogStackTraceForPid(const char*), which uses
 * the stacktrace script, to log the stack to a file.  Then it reads the lines
 * back in and puts them into an output iterator.
 */
template <class OutputIterator>
static void
_LogStackTraceToOutputIterator(OutputIterator oi, size_t maxDepth, bool addEndl)
{
    /* Could use tmpnam but we're trying to be minimalist here. */
    char logfile[1024];
    _GetStackTraceName(logfile, sizeof(logfile));

    _LogStackTraceForPid(false, logfile, "Log Stack Trace");

    ifstream inFile(logfile);
    string line;
    size_t currentDepth = 0;
    while(!inFile.eof() && currentDepth < maxDepth) {
        getline(inFile, line);
        if(addEndl && !inFile.eof())
            line += "\n";
        *oi++ = line;
        currentDepth ++;
    }

    inFile.close();
    ArchUnlinkFile(logfile);
}

#endif

/*
 * ArchPrintStackTrace
 *  print out a stack trace to the given FILE *.
 */
void
ArchPrintStackTrace(FILE *fout, const std::string& programName, const std::string& reason)
{
    ostringstream oss;

    ArchPrintStackTrace(oss, programName, reason);

    LibOpenUsdFprintf(fout, "%s", oss.str().c_str());
    if (fout) fflush(fout);
}

void
ArchPrintStackTrace(FILE* fout, const std::string& reason)
{
    ArchPrintStackTrace(fout, ArchGetProgramNameForErrors(), reason);
}

void
ArchPrintStackTrace(std::ostream& out, const std::string& reason)
{
    ArchPrintStackTrace(out, ArchGetProgramNameForErrors(), reason);
}

/*
 * ArchPrintStackTrace
 *  print out a stack trace to the given ostream.
 * 
 * This function should probably not be called from a signal handler as 
 * it calls printf and other unsafe functions.
 */
void
ArchPrintStackTrace(ostream& oss,
                    const std::string& programName,
                    const std::string& reason)
{
    oss << "==============================================================\n"
        << " A stack trace has been requested by "
        << programName << " because: " << reason << endl;

#if defined(ARCH_OS_DARWIN)

    _LogStackTraceToOutputIterator(ostream_iterator<string>(oss), numeric_limits<size_t>::max(), true);

#else

    vector<uintptr_t> frames;
    ArchGetStackFrames(MAX_STACK_DEPTH, &frames);
    ArchPrintStackFrames(oss, frames);

#endif

    oss << "==============================================================\n";
}

void
ArchGetStackTrace(ostream& oss, const std::string& reason)
{
    ArchPrintStackTrace(oss, ArchGetProgramNameForErrors(), reason);
}

void
ArchGetStackFrames(size_t maxDepth, vector<uintptr_t> *frames)
{
    ArchGetStackFrames(maxDepth, /* skip = */ 0, frames);
}

void
ArchGetStackFrames(size_t maxDepth, size_t skip, vector<uintptr_t> *frames)
{
    frames->resize(maxDepth);
    frames->resize(ArchGetStackFrames(maxDepth, skip, frames->data()));
}

#if defined(ARCH_OS_LINUX) && defined(ARCH_BITS_64)
struct Arch_UnwindContext {
public:
    Arch_UnwindContext(size_t maxdepth, size_t skip, uintptr_t* frames) :
        maxdepth(maxdepth), skip(skip), curdepth(0), frames(frames) {}

public:
    size_t maxdepth;
    size_t skip;
    size_t curdepth;
    uintptr_t* frames;
};

static _Unwind_Reason_Code
Arch_unwindcb(struct _Unwind_Context *ctx, void *data)
{   
    Arch_UnwindContext* context = static_cast<Arch_UnwindContext*>(data);

    // never extend frames because it is unsafe to alloc inside a
    // signal handler, and this function is called sometimes (when
    // profiling) from a signal handler.
    if (context->curdepth >= context->maxdepth) {
        return _URC_END_OF_STACK;
    }
    else {
        if (context->skip) {
            --context->skip;
        }
        else {
            context->frames[context->curdepth++] = _Unwind_GetIP(ctx);
        }
        return _URC_NO_REASON;
    }
}

/*
 * ArchGetStackFrames
 *  save some of stack into buffer.
 */
size_t
ArchGetStackFrames(size_t maxdepth, size_t skip, uintptr_t *frames)
{
    /* use the exception handling mechanism to unwind our stack.
     * note this is gcc >= 3.3.3 only.
     */
    Arch_UnwindContext context(maxdepth, skip, frames);
    _Unwind_Backtrace(Arch_unwindcb, (void*)&context);
    return context.curdepth;
}

#elif defined(ARCH_OS_WINDOWS)

size_t
ArchGetStackFrames(size_t maxdepth, size_t skip, uintptr_t *frames)
{
    void* stack[MAX_STACK_DEPTH];
    size_t frameCount = CaptureStackBackTrace(skip, MAX_STACK_DEPTH, stack, NULL);
    frameCount = std::min(frameCount, maxdepth);
    for (size_t frame = 0; frame != frameCount; ++frame) {
        frames[frame] = reinterpret_cast<uintptr_t>(stack[frame]);
    }
    return frameCount;
}

#elif defined(ARCH_OS_DARWIN)

size_t
ArchGetStackFrames(size_t maxdepth, size_t skip, uintptr_t *frames)
{
    void* stack[MAX_STACK_DEPTH];
    size_t maxFrames = std::min<size_t>(MAX_STACK_DEPTH, maxdepth+skip);
    const size_t frameCount = backtrace(stack, maxFrames);
    for (size_t frame = skip; frame != frameCount; ++frame) {
        *frames++ = reinterpret_cast<uintptr_t>(stack[frame]);
    }
    return frameCount-skip;
}

#else

size_t
ArchGetStackFrames(size_t, size_t, uintptr_t *)
{
}

#endif

static
std::string
Arch_DefaultStackTraceCallback(uintptr_t address)
{
    // Subtract one from the address before getting the info because
    // the stack frames have the addresses where we'll return to,
    // not where we called from.  We don't want the info for the
    // instruction after our calls, we want it for the call itself.
    // We don't need the exact address of the call because
    // ArchGetAddressInfo() will return the info for the closest
    // address is knows about that not after the given address.
    // (That's good because the address minus one is not the start
    // of the call instruction but there's no way to figure that out
    // here without decoding assembly instructions.)
    std::string objectPath, symbolName;
    void* baseAddress, *symbolAddress;
    if (ArchGetAddressInfo(reinterpret_cast<void*>(address - 1),
                   &objectPath, &baseAddress,
                   &symbolName, &symbolAddress) && symbolAddress) {
        Arch_DemangleFunctionName(&symbolName);
        const uintptr_t symbolOffset =
            (uint64_t)(address - (uintptr_t)symbolAddress);
        return ArchStringPrintf("%s+%#0lx", symbolName.c_str(), symbolOffset);
    }
    else {
        return "<unknown>";
    }
}

static
vector<string>
Arch_GetStackTrace(const vector<uintptr_t> &frames,
                   bool skipUnknownFrames=false);

/*
 * ArchPrintStackFrames
 *  print out stack frames to the given ostream.
 */
void
ArchPrintStackFrames(ostream& oss, const vector<uintptr_t> &frames,
                     bool skipUnknownFrames)
{
    const vector<string> result = Arch_GetStackTrace(frames, skipUnknownFrames);
    for (size_t i = 0; i < result.size(); i++) {
        oss << result[i] << std::endl;
    }
}

/*
 * ArchGetStackTrace
 *  vector of strings
 */
vector<string>
ArchGetStackTrace(size_t maxDepth)
{
    vector<uintptr_t> frames;
    ArchGetStackFrames(maxDepth, &frames);
    return Arch_GetStackTrace(frames);
}

static
ArchStackTraceCallback*
Arch_GetStackTraceCallback()
{
    static ArchStackTraceCallback callback;
    return &callback;
}

static vector<string>
Arch_GetStackTrace(const vector<uintptr_t> &frames,
                   bool skipUnknownFrames)
{
    vector<string> rv;

    if (frames.empty()) {
        rv.push_back("No frames saved, stack traces probably not supported "
                     "on this architecture.");
        return rv;
    }

    ArchStackTraceCallback callback = *Arch_GetStackTraceCallback();
    if (!callback) {
        callback = Arch_DefaultStackTraceCallback;
    }
    int n = 0;
    for (size_t i = 0; i < frames.size(); i++) {
        const std::string symbolic = callback(frames[i]);
        if (skipUnknownFrames && symbolic == "<unknown>") {
            continue;
        }
        rv.push_back(ArchStringPrintf(" #%-3i 0x%016lx in %s",
                                      n++, frames[i], symbolic.c_str()));
    }

    return rv;
}

void
ArchSetStackTraceCallback(const ArchStackTraceCallback& cb)
{
    *Arch_GetStackTraceCallback() = cb;
}

void
ArchGetStackTraceCallback(ArchStackTraceCallback* cb)
{
    if (cb) {
        *cb = *Arch_GetStackTraceCallback();
    }
}

/*
 * Replacement for 'system' safe for a crash handler
 *
 * This function is a substitute for system() which does not allocate
 * or free any data, and times out after timeout seconds if the
 * operation in  argv is not complete.  callback is called every
 * second.  userData is passed to callback.  callback can be used,
 * for example, to print a '.' repeatedly to show progress.  The alarm
 * used in this function could interfere with setitimer or other calls
 * to alarm, and this function uses non-locking fork and exec if available
 * so should  not generally be used except following a catastrophe.
 */
int
ArchCrashHandlerSystemv(const char* pathname, char *const argv[],
                        int timeout, ArchCrashHandlerSystemCB callback,
                        void* userData)
{
    // R owns process control; do not launch external crash reporters.
    return -1;
}

PXR_NAMESPACE_CLOSE_SCOPE

extern "C" {
ARCH_EXPORT
char const *Arch_GetExtraLogInfoReportDebugUnsafe()
{
    return PXR_NS::_GetExtraLogInfoReportDebugUnsafeImpl();
}
}

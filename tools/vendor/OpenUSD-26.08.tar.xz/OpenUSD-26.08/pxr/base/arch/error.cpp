// Modified for libopenusd by Tyler Morgan-Wall, 2026: R embedding; see tools/vendor/README.md.
#include "pxr/base/arch/rDiagnostics.h"
//
// Copyright 2016 Pixar
//
// Licensed under the terms set forth in the LICENSE.txt file available at
// https://openusd.org/license.
//

#include "pxr/pxr.h"
#include "pxr/base/arch/error.h"
#include "pxr/base/arch/debugger.h"
#include <stdio.h>

PXR_NAMESPACE_OPEN_SCOPE

void
Arch_Error(const char* cond, const char* funcName, size_t lineNo, const char* fileName)
{
    LibOpenUsdFprintf(nullptr, " ArchError: %s\n", cond);
    LibOpenUsdFprintf(nullptr, "  Function: %s\n", funcName);
    LibOpenUsdFprintf(nullptr, "      File: %s\n", fileName);
    LibOpenUsdFprintf(nullptr, "      Line: %zu\n", lineNo);
    ArchAbort();
}

void
Arch_Warning(const char* cond, const char* funcName, size_t lineNo, const char* fileName)
{
    LibOpenUsdFprintf(nullptr, " ArchWarn: %s\n", cond);
    LibOpenUsdFprintf(nullptr, " Function: %s\n", funcName);
    LibOpenUsdFprintf(nullptr, "     File: %s\n", fileName);
    LibOpenUsdFprintf(nullptr, "     Line: %zu\n", lineNo);
}

PXR_NAMESPACE_CLOSE_SCOPE

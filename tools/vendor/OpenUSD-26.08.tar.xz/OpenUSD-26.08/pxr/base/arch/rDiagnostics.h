// Modified for libopenusd by Tyler Morgan-Wall, 2026: R embedding; see tools/vendor/README.md.
// R embedding support for libopenusd; no R API calls from native workers.
#ifndef LIBOPENUSD_DIAGNOSTICS_H
#define LIBOPENUSD_DIAGNOSTICS_H
#include <stdio.h>
#include <stdarg.h>
#ifdef __cplusplus
#include <ostream>
#include <stdexcept>
extern "C" {
#endif
#if defined(__GNUC__) || defined(__clang__)
#if defined(__MINGW_PRINTF_FORMAT)
// Match the format dialect selected by MinGW's stdio implementation.
#define LIBOPENUSD_FORMAT(a, b) __attribute__((format(__MINGW_PRINTF_FORMAT, a, b)))
#else
#define LIBOPENUSD_FORMAT(a, b) __attribute__((format(printf, a, b)))
#endif
#else
#define LIBOPENUSD_FORMAT(a, b)
#endif
int LibOpenUsdPrintf(const char* format, ...) LIBOPENUSD_FORMAT(1, 2);
int LibOpenUsdFprintf(FILE* stream, const char* format, ...) LIBOPENUSD_FORMAT(2, 3);
int LibOpenUsdPuts(const char* text);
int LibOpenUsdFputs(const char* text, FILE* stream);
int LibOpenUsdPutchar(int character);
int LibOpenUsdDiagnosticNext(char* message, size_t capacity);
#ifdef __cplusplus
}
std::ostream& LibOpenUsdCout();
std::ostream& LibOpenUsdCerr();
// A fatal error invalidates the provider, even when caught inside upstream code.
class LibOpenUsdFatalError : public std::runtime_error {
public:
    explicit LibOpenUsdFatalError(const char* message) : std::runtime_error(message) {}
};
void LibOpenUsdRecordFailure(const char* message) noexcept;
[[noreturn]] void LibOpenUsdFatal(const char* message);
void LibOpenUsdCheckFailure();
#endif
#endif

// Modified for libopenusd by Tyler Morgan-Wall, 2026: R embedding; see tools/vendor/README.md.
//
// Copyright 2016 Pixar
//
// Licensed under the terms set forth in the LICENSE.txt file available at
// https://openusd.org/license.
//
/// \file debugger.cpp

#include "pxr/base/arch/debugger.h"
#include "pxr/base/arch/rDiagnostics.h"
PXR_NAMESPACE_OPEN_SCOPE
// Called by arch initialization even when debugger integration is disabled.
ARCH_HIDDEN void Arch_InitDebuggerAttach() {}
void ArchDebuggerTrap() {}
void ArchDebuggerWait(bool) {}
bool ArchDebuggerAttach() { return false; }
bool ArchDebuggerIsAttached() { return false; }
[[noreturn]] void ArchAbort(bool) { LibOpenUsdFatal("OpenUSD native invariant failure."); }
PXR_NAMESPACE_CLOSE_SCOPE
